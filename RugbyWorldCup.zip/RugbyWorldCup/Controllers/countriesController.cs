﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RugbyWorldCup.Models;

namespace RugbyWorldCup.Controllers
{
    public class countriesController : Controller
    {
        private RugbyWorldCupEntities db = new RugbyWorldCupEntities();

        // GET: countries
        public ActionResult Index()
        {
            return View(db.countries.ToList());
        }

        // GET: countries/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            country country = db.countries.Find(id);
            if (country == null)
            {
                return HttpNotFound();
            }
            return View(country);
        }

        // GET: countries/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: countries/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]

        //Bind(Include = "countryID,countryName,ranking,pool,flag,likes")]
        public ActionResult Create(country country)
        {
            if (ModelState.IsValid)
            {
                db.countries.Add(country);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(country);
        }

        //Functionality for the Like button
        [HttpPost]
        public ActionResult Like(int? id)
        {
            country country = db.countries.Find(id);
            if (country == null)
            {
                return HttpNotFound();
            }
            int currentLikes = (int)country.likes;
            country.likes = currentLikes + 1;

            if (ModelState.IsValid)
            {
                db.Entry(country).State = EntityState.Modified;
                db.SaveChanges();
            }

            country = db.countries.Find(id);

            return PartialView("_Indexpartial", country);

        }


        [HttpGet]
        public ActionResult _Indexpartial(int? countryID)
        {
            if(countryID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            country contry = db.countries.Find(countryID);

            if(contry==null)
            {
                return HttpNotFound();
            }

            return PartialView(contry);
        }


        // GET: countries/Edit/5
    public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            country country = db.countries.Find(id);
            if (country == null)
            {
                return HttpNotFound();
            }
            return View(country);
        }

        // POST: countries/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "countryID,countryName,ranking,pool,flag,likes")] country country)
        {
            if (ModelState.IsValid)
            {
                db.Entry(country).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(country);
        }

        // GET: countries/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            country country = db.countries.Find(id);
            if (country == null)
            {
                return HttpNotFound();
            }
            return View(country);
        }

        // POST: countries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            country country = db.countries.Find(id);
            db.countries.Remove(country);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public String Test()
        {
            return ("Ajax is working!");
        }



    }
}
